<?php

namespace RobinChat\Core;

/**
 * Returns the capability to check against
 */
function get_capability()
{
    if (current_user_can('manage_robin_chat')) {
        return 'manage_robin_chat';
    }
    
    return 'manage_options';
}
