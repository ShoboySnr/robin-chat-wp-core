<?php

namespace RobinChat\Core;

class RegisterScripts
{
    public function __construct()
    {
        add_action('admin_enqueue_scripts', array($this, 'admin_css'));
        add_action('wp_enqueue_scripts', array($this, 'public_css'));
    }
    
    
    public function public_css()
    {
        wp_enqueue_style('robin-chat-menu', ROBIN_CHAT_ASSETS_URL . 'dist/css/bundle.css', [], filemtime(ROBIN_CHAT_ASSETS_DIR . 'dist/css/bundle.css'));
    }
    
    
    /**
     * Robin Chat only css to fix conflicts
     */
    public function admin_css()
    {
        $screen = get_current_screen();
        
        $base_text = $screen->base;
    
        wp_enqueue_style('robin-chat-menu', ROBIN_CHAT_ASSETS_URL . 'css/admin/robin-chat-menu.css', [], filemtime(ROBIN_CHAT_ASSETS_DIR . 'css/admin/robin-chat-menu.css'));
    
        if (str_contains($base_text, 'robin-chat')) {
            wp_enqueue_style('robin-chat-admin', ROBIN_CHAT_ASSETS_URL . 'css/admin/admin.css', [], filemtime(ROBIN_CHAT_ASSETS_DIR . 'css/admin/admin.css'));
        }
        
    }
    
    /**
     * @return RegisterScripts
     */
    public static function get_instance()
    {
        static $instance = null;
        
        if (is_null($instance)) {
            $instance = new self();
        }
        
        return $instance;
    }
}