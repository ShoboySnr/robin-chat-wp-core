<?php

namespace RobinChat\Core\User;


class Init {
    
    public function __construct()
    {
        add_action('wp_footer', array($this, 'initialize_floating_chat_bubble'));
    }
    
    
    public function initialize_floating_chat_bubble()
    {
        $is_account_connected = get_option('ROBIN_CHAT_ACCOUNT_STATUS', false);
        if(is_admin() || $is_account_connected == false) return;
        
        
        
    }
    
    /**
     * Singleton.
     *
     * @return Init
     */
    public static function get_instance()
    {
        static $instance = null;
        
        if (is_null($instance)) {
            $instance = new self();
        }
        
        return $instance;
    }
}