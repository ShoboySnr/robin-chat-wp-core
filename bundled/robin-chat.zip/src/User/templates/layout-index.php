<?php
defined( 'ABSPATH' ) || exit;

$initialHeight = (int) apply_filters( 'robin_chat_max_height', Better_Messages()->settings['messagesHeight'] );
echo '<div class="bp-messages-wrap-main" style="height: ' . $initialHeight . 'px">' . Better_Messages()->functions->container_placeholder() . '</div>';
