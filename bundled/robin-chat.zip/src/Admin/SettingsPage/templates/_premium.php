<?php
  defined( 'ABSPATH' ) || exit;
  if(!defined('ROBIN_CHAT_DETACH_LIBSODIUM')) {
?>
<a href="#" title="<?php echo __('Go Premium', 'robin-chat'); ?>">
  <img src="<?php echo ROBIN_CHAT_ASSETS_URL. '/images/robin-premium.png'; ?>" alt="robin-chat-premium" />
</a>
<?php
}
?>